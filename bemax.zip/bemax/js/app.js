$(document).ready(function() {
    //form menu
    $("#dropdown-container-home").hover(function() {
        $("#dropdown-home").slideToggle()
    })
    $("#dropdown-container-2").hover(function() {
        $("#dropdown-2").slideToggle()
    })
    $("#dropdown-container-pages").hover(function() {
        $("#dropdown-pages").slideToggle()
    })
    $("#dropdown-container-portfolio").hover(function() {
        $("#dropdown-portfolio").slideToggle()
    })
    $("#dropdown-container-portfolio-3rd").hover(function() {
            $("#dropdown-portfolio-3rd").slideToggle()
        })
        //mean menu activation
    jQuery('.menu').meanmenu({
            meanMenuContainer: '#mobile-menu',
            meanMenuOpen: "<span></span><span></span> <span> </span>",
            meanScreenWidth: 1050,
        })
        //search window
        //search window open
    jQuery("#search-btn").click(function() {
            jQuery(".search-window").css({
                opacity: 1,
                visibility: "visible"
            })
        })
        //search window close
    jQuery(".search-interface-close-btn").click(function() {
            jQuery(".search-window").css({
                opacity: 0,
                visibility: "hidden"
            })
        })
        //main slider active
    $('.slider-section .owl-carousel').owlCarousel({
            loop: true,
            nav: true,
            navText: ['<i class="fas fa-angle-left fa-2x"></i>', '<i class="fas fa-angle-right fa-2x"></i>'],
            items: 1
        })
        //show case slider active
    $('.showcase-section .owl-carousel').owlCarousel({
        loop: true,
        nav: true,
        navText: ['<i class="fa fa-angle-left fa-2x"></i>', '<i class="fa fa-angle-right fa-2x"></i>'],
        autoplay: true,
        responsive: {
            0: {
                items: 1
            },
            400: {
                items: 2
            },
            1000: {
                items: 4

            }
        }
    })
    $('.blog-active').owlCarousel({
        loop: true,
        nav: true,
        navText: ['<i class="fa fa-angle-left fa-2x"></i>', '<i class="fa fa-angle-right fa-2x"></i>'],
        autoplay: true,
        items: 1,

    })
    $('.brand-active').owlCarousel({
            loop: false,
            nav: false,
            navText: ['<i class="fa fa-angle-left fa-2x"></i>', '<i class="fa fa-angle-right fa-2x"></i>'],
            autoplay: false,
            margin: 70,
            responsive: {
                0: {
                    items: 2

                },
                400: {
                    items: 3
                },
                1000: {
                    items: 5

                }
            }

        })
        //magnific popup
    jQuery(".video-popup").magnificPopup({
        type: "iframe",
        mainClass: "mfp-fade",
        removalDelay: 800,
        iframe: {
            markup: '<div class="mfp-iframe-scaler">' +
                '<div class="mfp-close"></div>' +
                '<iframe class="mfp-iframe" frameborder="1" allowfullscreen></iframe>' +
                '</div>',
            patterns: {
                youtube: {
                    index: 'https://www.youtube.com/embed/%id%?autoplay=1',
                    id: 'v=',
                    src: 'https://www.youtube.com/embed/%id%?autoplay=1'
                },

            }
        }
    })
    $("#sticker").sticky({ bottomSpacing: 0 });

})